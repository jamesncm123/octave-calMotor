function cal(a,b,c)  alpha = [a,b,c];  alphaShift90 = alpha + 90;  alphaShift90Radius = alphaShift90 * pi/180;  A = [cos(alphaShift90Radius);sin(alphaShift90Radius);ones(1,3);]  AInv = inv(A)  val = AInv.*[0,-1,0]
endfunction
